//Search for images with an api key and show the output
var apiKey = '3xwzea8hh3agnzw3mysgdpn9';
var phrase = '';
var preurl = 'https://api.gettyimages.com/v3/search/images?fields=id,title,thumb,referral_destinations&sort_order=best&phrase=';
var fullurl = preurl + phrase + ' music';

$.ajax(
    {
        type:'GET',
        url:fullurl,
         beforeSend: function (request)
            {
                request.setRequestHeader("Api-Key", apiKey);
            }})
    .done(function(data){
        console.log("Success with data")
        for(var i = 0;i<15;i++)
        {
           $("#output").append("<img src='" + data.images[i].display_sizes[0].uri + "'/>");
        }
    })
    .fail(function(data){
        alert(JSON.stringify(data,10))
    });