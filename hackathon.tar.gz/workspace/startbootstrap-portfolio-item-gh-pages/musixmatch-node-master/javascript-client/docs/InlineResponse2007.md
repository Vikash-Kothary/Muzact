# MusixmatchApi.InlineResponse2007

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | [**InlineResponse2007Message**](InlineResponse2007Message.md) |  | [optional] 


