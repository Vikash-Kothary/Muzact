# MusixmatchApi.InlineResponse20010Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse20010MessageBody**](InlineResponse20010MessageBody.md) |  | [optional] 


