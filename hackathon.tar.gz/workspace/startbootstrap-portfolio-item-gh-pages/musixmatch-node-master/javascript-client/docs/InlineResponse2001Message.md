# MusixmatchApi.InlineResponse2001Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2001MessageHeader**](InlineResponse2001MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2001MessageBody**](InlineResponse2001MessageBody.md) |  | [optional] 


