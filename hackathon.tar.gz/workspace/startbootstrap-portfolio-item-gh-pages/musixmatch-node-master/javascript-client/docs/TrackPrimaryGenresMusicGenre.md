# MusixmatchApi.TrackPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreVanity** | **String** |  | [optional] 
**musicGenreNameExtended** | **String** |  | [optional] 
**musicGenreName** | **String** |  | [optional] 
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreId** | **Number** |  | [optional] 


