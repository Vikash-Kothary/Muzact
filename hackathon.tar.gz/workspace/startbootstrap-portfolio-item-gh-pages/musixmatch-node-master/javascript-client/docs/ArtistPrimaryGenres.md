# MusixmatchApi.ArtistPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[ArtistPrimaryGenresMusicGenreList]**](ArtistPrimaryGenresMusicGenreList.md) |  | [optional] 


