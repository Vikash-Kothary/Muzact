# MusixmatchApi.InlineResponse2007Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse200MessageHeader**](InlineResponse200MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2007MessageBody**](InlineResponse2007MessageBody.md) |  | [optional] 


