# MusixmatchApi.InlineResponse2006MessageBodyTrackList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**track** | [**Track**](Track.md) |  | [optional] 


