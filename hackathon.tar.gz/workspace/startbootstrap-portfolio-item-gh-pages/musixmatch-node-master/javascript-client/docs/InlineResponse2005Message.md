# MusixmatchApi.InlineResponse2005Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2005MessageHeader**](InlineResponse2005MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2004MessageBody**](InlineResponse2004MessageBody.md) |  | [optional] 


