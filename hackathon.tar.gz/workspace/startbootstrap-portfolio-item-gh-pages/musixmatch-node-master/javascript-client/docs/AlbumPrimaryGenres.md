# MusixmatchApi.AlbumPrimaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[AlbumPrimaryGenresMusicGenreList]**](AlbumPrimaryGenresMusicGenreList.md) |  | [optional] 


