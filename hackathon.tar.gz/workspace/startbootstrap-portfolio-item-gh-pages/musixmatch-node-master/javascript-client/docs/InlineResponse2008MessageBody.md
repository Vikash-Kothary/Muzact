# MusixmatchApi.InlineResponse2008MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subtitle** | [**Subtitle**](Subtitle.md) |  | [optional] 


