# MusixmatchApi.InlineResponse2001MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**statusCode** | **Number** |  | [optional] 
**available** | **Number** |  | [optional] 
**executeTime** | **Number** |  | [optional] 


