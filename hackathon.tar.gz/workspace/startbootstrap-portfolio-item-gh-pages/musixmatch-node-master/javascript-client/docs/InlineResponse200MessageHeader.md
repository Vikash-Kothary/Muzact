# MusixmatchApi.InlineResponse200MessageHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**statusCode** | **Number** |  | [optional] 
**executeTime** | **Number** |  | [optional] 


