# MusixmatchApi.AlbumPrimaryGenresMusicGenreList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenre** | [**AlbumPrimaryGenresMusicGenre**](AlbumPrimaryGenresMusicGenre.md) |  | [optional] 


