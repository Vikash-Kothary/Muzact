# MusixmatchApi.InlineResponse2006Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**InlineResponse2005MessageHeader**](InlineResponse2005MessageHeader.md) |  | [optional] 
**body** | [**InlineResponse2006MessageBody**](InlineResponse2006MessageBody.md) |  | [optional] 


