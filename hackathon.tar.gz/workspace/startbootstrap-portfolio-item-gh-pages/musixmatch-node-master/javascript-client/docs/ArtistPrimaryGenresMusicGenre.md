# MusixmatchApi.ArtistPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreName** | **String** |  | [optional] 
**musicGenreVanity** | **String** |  | [optional] 
**musicGenreId** | **Number** |  | [optional] 
**musicGenreNameExtended** | **String** |  | [optional] 


