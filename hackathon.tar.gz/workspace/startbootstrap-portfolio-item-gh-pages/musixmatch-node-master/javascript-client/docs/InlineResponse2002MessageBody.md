# MusixmatchApi.InlineResponse2002MessageBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**albumList** | [**[InlineResponse200MessageBody]**](InlineResponse200MessageBody.md) | A list of albums | [optional] 


