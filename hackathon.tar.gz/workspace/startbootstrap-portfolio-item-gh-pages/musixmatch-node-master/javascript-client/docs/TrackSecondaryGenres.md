# MusixmatchApi.TrackSecondaryGenres

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreList** | [**[TrackSecondaryGenresMusicGenreList]**](TrackSecondaryGenresMusicGenreList.md) |  | [optional] 


