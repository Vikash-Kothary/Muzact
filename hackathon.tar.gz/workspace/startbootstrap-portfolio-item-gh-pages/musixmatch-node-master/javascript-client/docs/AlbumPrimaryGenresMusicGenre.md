# MusixmatchApi.AlbumPrimaryGenresMusicGenre

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**musicGenreNameExtended** | **String** |  | [optional] 
**musicGenreVanity** | **String** |  | [optional] 
**musicGenreParentId** | **Number** |  | [optional] 
**musicGenreId** | **Number** |  | [optional] 
**musicGenreName** | **String** |  | [optional] 


