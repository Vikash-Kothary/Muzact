var MusixmatchApi = require('javascript-client/src/index.js')
var defaultClient = MusixmatchApi.ApiClient.instance;
var key = defaultClient.authentications['key'];
key.apiKey = "50fce709613e1e8d8f0e1981c4f58a93"; // {String} 
var opts = {
    format: "json", // {String} output format: json, jsonp, xml.
};
var trackId= 15445219; // {number}
(new MusixmatchApi.TrackApi()).trackGetGet(trackId, opts, (error, data, response) => {
    if (error) {
        console.error(error);
    } else if(response.text) {
        data = JSON.parse(response.text);
        console.log('Returned data:\n%s' ,JSON.stringify(data,null,2));
    }
    else {
        throw new Error('bad response')   
    }
} );