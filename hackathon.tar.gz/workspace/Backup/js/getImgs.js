//Search for images with an api key and show the output
var apiKey = 'yhb9zk28ymdya7d3hjuuk38v';
var phrase = 'radiohead';
//var preurl = 'https://api.gettyimages.    com/v3/search/images?fields=id,title,thumb,referral_destinations&sort_order=best&phrase=';
var preurl = 'https://api.gettyimages.com/v3/search/images/editorial?phrase=';
var fullurl = preurl + phrase + ' music';
var imageIDs=["#img1","#img2","#img3","#img4","#img5"];

$.ajax(
    {
        type:'GET',
        url:fullurl,
         beforeSend: function (request)
            {
                request.setRequestHeader("Api-Key", apiKey);
            }})
    .done(function(data){
        console.log("Success with data")
        for(var i = 0;i<5;i++)
        {
           $(imageIDs[i]).append("<img src='" + data.images[i].display_sizes[0].uri + "'/>");
        }
    })
    .fail(function(data){
        alert(JSON.stringify(data,10))
    });